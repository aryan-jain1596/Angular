import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Product } from '../model/product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

@Output()
newproduct: EventEmitter<Product> = new EventEmitter<Product>();

product:any
  constructor() { }

  ngOnInit(): void {
  }
  addProduct(product:any){
    this.newproduct.emit(product.value);
    // this.ps.addProduct(product)
    // this.product=product.value
    // console.log("Product",product.value)
  }
}
