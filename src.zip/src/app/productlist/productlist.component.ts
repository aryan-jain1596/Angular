import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { Product } from '../model/product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})

export class ProductlistComponent implements OnInit,OnChanges {
  @Input()
  newproduct:any
  product: any = [{ id: 1, name: "pencil", price: 15.0 }, { id: 2, name: "eraser", price: 5.0 }, { id: 3, name: "notebook", price: 30.0 }, { id: 4, name: "sharpner", price: 12.0 }]
  constructor() { }

  ngOnInit(): void {
    console.log(this.product[0])
    
  }
  ngOnChanges(changes: SimpleChanges): void {
    if(this.newproduct.name!=''){
      this.product.push(this.newproduct)
    }
    
  }
  

}
