import { Injectable } from '@angular/core';
import { Product } from '../model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  product!: Product
  constructor() { }
  addProduct(product: Product) {
    this.product = product;
  }
}
